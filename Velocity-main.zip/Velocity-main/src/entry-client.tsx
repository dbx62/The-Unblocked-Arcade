import { StartClient, mount } from "solid-start/entry-client";

mount(() => <StartClient />, document);
