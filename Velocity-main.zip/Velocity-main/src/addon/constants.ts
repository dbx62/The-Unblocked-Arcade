export const ADDON_DIR = "/Velocity/addons/";
export const ADDON_STORE_DIR = "/Velocity/addon-store/";
export const ADN_API_ROT = "https://addons.mozilla.org/api/v5/addons/addon/";
export const MOZILLA_RSA_PATH = "META-INF/mozilla.rsa";
