let lastError: Error | undefined;
let id: string = "";

export default { lastError, id };
