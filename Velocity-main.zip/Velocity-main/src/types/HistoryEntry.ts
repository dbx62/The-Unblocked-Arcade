export default interface HistoryEntry {
  id: number;
  url: string;
  title: string;
  favicon: string;
  timestamp: number;
}
